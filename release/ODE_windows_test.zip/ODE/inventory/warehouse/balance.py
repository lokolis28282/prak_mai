"""Balance boundary placeholder."""
