# ODE 0.12.16 RC1 Release Notes

Status: Release Candidate for testing.

This package includes:

- warehouse;
- equipment and component receipt;
- equipment and component issue;
- separate cable accounting;
- deliveries;
- physical delivery acceptance;
- balance;
- history;
- daily and weekly reports;
- profile.

Delivery acceptance was confirmed by Stage 0.12.16A end-to-end acceptance in
headless Chrome. The validation suite passed 158 tests.

Limitations:

- close delivery remains compatibility/legacy;
- destructive override for conflicting existing data is not implemented;
- Monitoring is still in development;
- external system APIs are not connected;
- server deployment has not been performed;
- this build is intended for test operation, not production.
