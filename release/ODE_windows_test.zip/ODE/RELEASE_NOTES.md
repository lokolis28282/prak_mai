# ODE 0.12.17 RC1 Release Notes

Status: Release Candidate for controlled local pilot.

This package includes:

- warehouse;
- equipment and component receipt;
- equipment and component issue;
- separate cable accounting;
- deliveries;
- physical delivery acceptance;
- balance;
- history;
- daily and weekly reports;
- profile.
- dashboard and global search;
- equipment card with operational history;
- bounded large-data views and session-isolated previews.

The validation suite passed 185 tests. End-to-end headless Chrome acceptance
covered engineer and administrator login, warehouse operations, global search,
Back/reload, reports, deliveries, mobile navigation and zero HTTP/JS/resource errors.

Limitations:

- close delivery remains compatibility/legacy;
- destructive override for conflicting existing data is not implemented;
- Monitoring is still in development;
- external system APIs are not connected;
- server deployment has not been performed;
- deployment is limited to one local ODE process and one local SQLite file;
- this build requires target Windows acceptance before production rollout.
