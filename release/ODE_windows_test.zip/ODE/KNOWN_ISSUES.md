# Known Issues

- close_delivery is still compatibility/legacy.
- Destructive override for conflicting existing warehouse data is absent.
- Monitoring is a placeholder.
- Part of the frontend remains in legacy ui.js.
- WarehouseCore remains a compatibility core.
- Physical Windows launch must be confirmed on the target laptop.
- Scheduled automatic backup is not implemented.
- Server deployment is not implemented.
- One CSV import is limited to 40,000 non-empty rows.
- Corrective/reversal operations are not implemented.
